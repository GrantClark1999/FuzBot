const fetch = require('node-fetch');

function getExchangeUrl(authCode) {
  const baseUrl = process.env.BASE_URL;
  const clientId = `client_id=${process.env.CLIENT_ID}`;
  const clientSecret = `client_secret=${process.env.CLIENT_SECRET}`;
  const code = `code=${authCode}`;
  const grantType = `grant_type=${process.env.GRANT_TYPE}`;
  const redirectUri = `redirect_uri=${process.env.REDIRECT_URI}`;

  const queryParams = [
    clientId,
    clientSecret,
    code,
    grantType,
    redirectUri,
  ].join('&');
  return [baseUrl, queryParams].join('?');
}

exports.handler = async (event) => {
  let body;
  let statusCode = '200';
  const headers = {
    'Content-Type': 'application/json',
  };
  
  try {
    const code = JSON.parse(event.body).code;
    if (!code) {
      throw new Error('Body must include "code"');
    }
    const url = getExchangeUrl(code);
    const response = await fetch(url, { method: 'POST' });
    body = await response.json();
  } catch (err) {
    statusCode = '400';
    body = err.message;
  } finally {
    body = JSON.stringify(body);
  }
  
  return {
    statusCode,
    body,
    headers,
  };
};