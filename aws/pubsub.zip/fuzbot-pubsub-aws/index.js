const fetch = require('node-fetch');

function getRefreshUrl(refresh_token) {
  const twitchUrl = 'https://id.twitch.tv/oauth2/token';
  const grantType = 'grant_type=refresh_token';
  const refreshToken = `refresh_token=${encodeURIComponent(refresh_token)}`;
  const clientId = `client_id=${encodeURIComponent(process.env.CLIENT_ID)}`;
  const clientSecret = `client_secret=${encodeURIComponent(
    process.env.CLIENT_SECRET
  )}`;

  const query = [grantType, refreshToken, clientId, clientSecret].join('&');
  return [twitchUrl, query].join('?');
}

exports.handler = async (event) => {
  let body;
  let statusCode = '200';
  const headers = {
    'Content-Type': 'application/json',
  };

  try {
    const refreshToken = JSON.parse(event.body).refresh_token;
    if (!refreshToken) {
      throw new Error('Body must include "refresh_token"');
    }
    const url = getRefreshUrl(refreshToken);
    const response = await fetch(url, { method: 'POST' });
    body = await response.json();
  } catch (err) {
    statusCode = '400';
    body = err.message;
  } finally {
    body = JSON.stringify(body);
  }
  
  return {
    statusCode,
    body,
    headers,
  };
};
